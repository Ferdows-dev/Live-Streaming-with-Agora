package com.fer.streaming.Modeks;

import java.security.PrivateKey;

public class HostLiveChats {
    private String userId;
    private String messageId;
    private String message;

    public HostLiveChats() {
    }

    public HostLiveChats(String userId, String messageId, String message) {
        this.userId = userId;
        this.messageId = messageId;
        this.message = message;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
