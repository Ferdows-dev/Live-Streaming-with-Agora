package com.fer.streaming.Commons;

import com.fer.streaming.Modeks.HostInfoModel;
import com.fer.streaming.Modeks.UserInfoModel;

public class Common {
    public static final String USER_INFO_REFERENCE = "StreamUsers" ;
    public static final String HOST_REGISTRATION = "HostList" ;
    public static UserInfoModel currentUser;
    public static HostInfoModel currentHostReg;
    public static final String AGORA_APP_ID = "25aef989a45443aba6b282be326e60ed";

    public static String buidWelcomeMessage() {
        if (Common.currentUser != null){
            return new StringBuilder("Welcome ")
                    .append(Common.currentUser.getFirstName())
                    .append(" ")
                    .append(Common.currentUser.getLastName()).toString();
        }else {
            return "";
        }
    }
}
