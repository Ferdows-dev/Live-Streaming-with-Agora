package com.fer.streaming.Ui;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.fer.streaming.R;
import com.google.android.material.tabs.TabLayout;

public class HomeFragment extends Fragment {


    private LiveFragment liveFragment;
    private GameFragment gameFragment;


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        liveFragment = new LiveFragment();
        gameFragment = new GameFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get the TabLayout and ViewPager from the parent fragment's XML layout
        TabLayout tabLayout = view.findViewById(R.id.tab_layout);
        ViewPager viewPager = view.findViewById(R.id.view_pager);

        // Create a FragmentPagerAdapter to manage the child fragments
        FragmentPagerAdapter adapter = new FragmentPagerAdapter(getChildFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                // Return the child fragment for the specified position
                if (position == 0) {
                    return liveFragment;
                } else {
                    return gameFragment;
                }
            }

            @Override
            public int getCount() {
                // Return the number of child fragments
                return 2;
            }

            @Nullable
            @Override
            public CharSequence getPageTitle(int position) {
                // Return the title for the specified position
                if (position == 0) {
                    return "Live";
                } else {
                    return "Games";
                }
            }
        };
        // Set the adapter on the ViewPager
        viewPager.setAdapter(adapter);

        // Connect the TabLayout and ViewPager
        tabLayout.setupWithViewPager(viewPager);
    }
}