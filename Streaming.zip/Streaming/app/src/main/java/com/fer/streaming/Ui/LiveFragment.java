package com.fer.streaming.Ui;


import static com.firebase.ui.auth.AuthUI.getApplicationContext;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.fer.streaming.Commons.Common;
import com.fer.streaming.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import io.agora.rtc2.Constants;
import io.agora.rtc2.IRtcEngineEventHandler;
import io.agora.rtc2.RtcEngine;
import io.agora.rtc2.RtcEngineConfig;
import io.agora.rtc2.video.VideoCanvas;
import io.agora.rtc2.video.VideoEncoderConfiguration;


public class LiveFragment extends Fragment {

//    private static final String CHANNEL_NAME = "MyChannel";
//    private static final int PERMISSION_REQ_ID = 100;
//
//    private RtcEngine engine;
//    private SurfaceView localView;
private RtcEngine mRtcEngine;
    private final String appId = "f50ae2f9b6f3433d9cac72a4e268e012";

    private EditText mChannelEditText;
    private Button mJoinButton;
    private TextView mLogTextView;
    private boolean mJoined = false;
    private int mRemoteUid = 0;
    private FirebaseDatabase firebaseDatabase;
    DatabaseReference hostRef;
    //    private SurfaceView remoteView;
    private Button liveButton;
//    private Button stopButton;

    private boolean isStreaming = false;
    ConstraintLayout layoutNoLive,layoutStartLive;

    private Switch audienceRole;;

    Context context;

    public LiveFragment() {
        // Required empty public constructor
    }

    @Override
    public void onStart() {
        super.onStart();
//        if (Common.currentUser != null )
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }



    private final IRtcEngineEventHandler mRtcEventHandler = new IRtcEngineEventHandler() {
        @Override
        public void onJoinChannelSuccess(String channel, int uid, int elapsed) {
            log("onJoinChannelSuccess " + channel + " " + uid);
            runOnUiThread(() -> {
                mJoinButton.setText("Leave");
                mJoined = true;
            });
        }

        @Override
        public void onUserJoined(int uid, int elapsed) {
            log("onUserJoined " + uid);
            runOnUiThread(() -> {
                if (mRemoteUid == 0) {
                    mRemoteUid = uid;
                    mRtcEngine.setupRemoteVideo(new VideoCanvas(getView().findViewById(R.id.local_video_view), VideoCanvas.RENDER_MODE_FIT, uid));
                }
            });
        }

        @Override
        public void onUserOffline(int uid, int reason) {
            log("onUserOffline " + uid);
            runOnUiThread(() -> {
                if (mRemoteUid == uid) {
                    mRemoteUid = 0;
                    mRtcEngine.setupRemoteVideo(new VideoCanvas(getView().findViewById(R.id.local_video_view), VideoCanvas.RENDER_MODE_HIDDEN, 0));
                }
            });
        }

        @Override
        public void onLeaveChannel(RtcStats stats) {
            log("onLeaveChannel");
            runOnUiThread(() -> {
                mJoinButton.setText("Join");
                mJoined = false;
                mRemoteUid = 0;
                mRtcEngine.setupRemoteVideo(new VideoCanvas(getView().findViewById(R.id.local_video_view), VideoCanvas.RENDER_MODE_HIDDEN, 0));
            });
        }
    };




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_live, container, false);


        firebaseDatabase = FirebaseDatabase.getInstance();
        hostRef = firebaseDatabase.getReference(Common.HOST_REGISTRATION);
        layoutNoLive = view.findViewById(R.id.no_live_fragment_layout);
        layoutStartLive = view.findViewById(R.id.layout_for_live_start);
        hostRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()){
                                    String isApproved = snapshot.child("approved").getValue().toString();
                                    if (isApproved == "false" && isStreaming == false){
                                        layoutNoLive.setVisibility(View.VISIBLE);
                                        layoutStartLive.setVisibility(View.GONE);

                                    }else if (isApproved == "true"){
                                        layoutNoLive.setVisibility(View.GONE);
                                        layoutStartLive.setVisibility(View.VISIBLE);
                                        inIT(view);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });





        return view;
    }

    private void inIT(View view) {
        mChannelEditText = view.findViewById(R.id.channel_edit_text);
        mJoinButton = view.findViewById(R.id.join_button);
        mLogTextView = view.findViewById(R.id.log_text_view);

        RtcEngineConfig rtcEngineConfig = new RtcEngineConfig();
        config.mContext = getBaseContext();
        config.mAppId = appId;
        config.mEventHandler = mRtcEventHandler;
        agoraEngine = RtcEngine.create(config);
        rtcEngineConfig.se("YOUR_APP_ID");
        mRtcEngine = RtcEngine.create(, rtcEngineConfig);
        mRtcEngine.setChannelProfile(Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
        mRtcEngine.setClientRole(Constants.CLIENT_ROLE_BROADCASTER);
        mRtcEngine.setVideoEncoderConfiguration(new VideoEncoderConfiguration(
                VideoEncoderConfiguration.VD_640x360,
                VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15,
                VideoEncoderConfiguration.STANDARD_BITRATE,
                VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_FIXED_PORTRAIT));

        mRtcEngine.setEventHandler(mRtcEventHandler);

        mJoinButton.setOnClickListener(v -> {
            if (mJoined) {
                mRtcEngine.leaveChannel();
            } else {
    }



}