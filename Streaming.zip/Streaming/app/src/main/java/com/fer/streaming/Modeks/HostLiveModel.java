package com.fer.streaming.Modeks;

public class HostLiveModel {
    private String hostId;
    private String liveStartTime;
    private String liveEndTime;
    private String getGifts;


    public HostLiveModel() {
    }

    public String getHostId() {
        return hostId;
    }

    public void setHostId(String hostId) {
        this.hostId = hostId;
    }

    public String getLiveStartTime() {
        return liveStartTime;
    }

    public void setLiveStartTime(String liveStartTime) {
        this.liveStartTime = liveStartTime;
    }

    public String getLiveEndTime() {
        return liveEndTime;
    }

    public void setLiveEndTime(String liveEndTime) {
        this.liveEndTime = liveEndTime;
    }

    public String getGetGifts() {
        return getGifts;
    }

    public void setGetGifts(String getGifts) {
        this.getGifts = getGifts;
    }
}
