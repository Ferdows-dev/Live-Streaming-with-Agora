package com.fer.streaming.Modeks;

public class HostInfoModel {
    private String hostName,hostPhone,hostEmail,hostCountry,hostNationalID;
    private boolean isApproved;
    private String nationalIdImageofHost;
    private String holdingNationalIdImageofHost;



    public HostInfoModel() {
    }

    public HostInfoModel(String hostName, String hostPhone, String hostEmail, String hostCountry, String hostNationalID,boolean isApproved) {
        this.hostName = hostName;
        this.hostPhone = hostPhone;
        this.hostEmail = hostEmail;
        this.hostCountry = hostCountry;
        this.hostNationalID = hostNationalID;
        this.isApproved = isApproved;

    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getHostPhone() {
        return hostPhone;
    }

    public void setHostPhone(String hostPhone) {
        this.hostPhone = hostPhone;
    }

    public String getHostEmail() {
        return hostEmail;
    }

    public void setHostEmail(String hostEmail) {
        this.hostEmail = hostEmail;
    }

    public String getHostCountry() {
        return hostCountry;
    }

    public void setHostCountry(String hostCountry) {
        this.hostCountry = hostCountry;
    }

    public String getHostNationalID() {
        return hostNationalID;
    }

    public void setHostNationalID(String hostNationalID) {
        this.hostNationalID = hostNationalID;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void setApproved(boolean approved) {
        isApproved = approved;
    }

    public String getNationalIdImageofHost() {
        return nationalIdImageofHost;
    }

    public void setNationalIdImageofHost(String nationalIdImageofHost) {
        this.nationalIdImageofHost = nationalIdImageofHost;
    }

    public String getHoldingNationalIdImageofHost() {
        return holdingNationalIdImageofHost;
    }

    public void setHoldingNationalIdImageofHost(String holdingNationalIdImageofHost) {
        this.holdingNationalIdImageofHost = holdingNationalIdImageofHost;
    }
}
