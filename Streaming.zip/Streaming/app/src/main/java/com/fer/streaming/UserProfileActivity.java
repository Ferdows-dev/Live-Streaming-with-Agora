package com.fer.streaming;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.fer.streaming.Commons.Common;

public class UserProfileActivity extends AppCompatActivity {

    private ImageView userAvatar;
    private TextView userName;
    private LinearLayout hostRegistrationLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);




        userAvatar = findViewById(R.id.img_avatar_profile);
        userName = findViewById(R.id.name_tv);
        hostRegistrationLayout = findViewById(R.id.host_registration_layout);

        if (Common.currentUser != null && Common.currentUser.getAvatar() != null && !TextUtils.isEmpty(Common.currentUser.getAvatar()))
        {
            Glide.with(this)
                    .load(Common.currentUser.getAvatar())
                    .into(userAvatar);
        }else{
            Log.d("imguser","not found");
        }

        userName.setText(Common.buidWelcomeMessage());





        hostRegistrationLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserProfileActivity.this,HostRegistrationActivity.class));
            }
        });
    }
}