package com.fer.streaming;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.fer.streaming.Commons.Common;
import com.fer.streaming.Commons.UserUtills;
import com.fer.streaming.Modeks.HostInfoModel;
import com.fer.streaming.Ui.HomeFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class HostRegistrationActivity extends AppCompatActivity {

    private static final int PICK_NATINAL_ID_IMG_REQUEST = 7172 ;
    private static final int HOLDING_NATINAL_ID_IMG_REQUEST = 7173 ;

    private Spinner countrySpinner;
    private EditText hostRegName,hostRegPhone,hostRegAddress,hostRegEmail,hostRegNationalID;
    private TextView clickToUploadNationalId,holdYourNationalIDinYourHands;
    private ImageView hostNationalId,hostHoldingNationalId;
    private Button submitBtn;
    private Uri nationalIdimgUri;
    private Uri holdingNationalIdimgUri;
    private boolean isApproved;

    private FirebaseDatabase firebaseDatabase;
    DatabaseReference hostRef;
    private StorageReference storageReference;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_registration);

        countrySpinner = findViewById(R.id.countrySpinner);

        isApproved = false;

        String[] countries = {"Bangladesh", "India", "Sri Lanka","Pakistan","USA","UK","France","Spain","Germany","China"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, countries);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        countrySpinner.setAdapter(adapter);

        inIT();

    }

    private void inIT() {

        firebaseDatabase = FirebaseDatabase.getInstance();
        hostRef = firebaseDatabase.getReference(Common.HOST_REGISTRATION);
        storageReference = FirebaseStorage.getInstance().getReference();

        hostRegName = findViewById(R.id.nameEditText);
        hostRegPhone = findViewById(R.id.phoneEditText);
        hostRegAddress = findViewById(R.id.addressEditText);
        hostRegEmail = findViewById(R.id.emailEditText);
        hostRegNationalID = findViewById(R.id.nationalIdEditText);
        clickToUploadNationalId = findViewById(R.id.upload_national_image);
        holdYourNationalIDinYourHands = findViewById(R.id.upload_holding_national_image);
        hostNationalId = findViewById(R.id.national_id_img);
        hostHoldingNationalId = findViewById(R.id.holding_national_id_img);
        submitBtn = findViewById(R.id.submitBtn);

        clickToUploadNationalId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(intent,PICK_NATINAL_ID_IMG_REQUEST);
            }
        });

        hostHoldingNationalId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(intent,HOLDING_NATINAL_ID_IMG_REQUEST);
            }
        });

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(hostRegName.getText().toString())){
                    Toast.makeText(HostRegistrationActivity.this, "Please enter your real name", Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(hostRegPhone.getText().toString())){
                    Toast.makeText(HostRegistrationActivity.this, "Please enter your phone no", Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(countrySpinner.getSelectedItem().toString())){
                    Toast.makeText(HostRegistrationActivity.this, "Please select your country", Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(hostRegEmail.getText().toString())){
                    Toast.makeText(HostRegistrationActivity.this, "Please enter your email address", Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(hostRegNationalID.getText().toString())){
                    Toast.makeText(HostRegistrationActivity.this, "Please enter your valid national Id", Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    HostInfoModel hostInfoModel = new HostInfoModel();
                    hostInfoModel.setHostName(hostRegName.getText().toString());
                    hostInfoModel.setHostPhone(hostRegPhone.getText().toString());
                    hostInfoModel.setHostCountry(countrySpinner.getSelectedItem().toString());
                    hostInfoModel.setHostEmail(hostRegEmail.getText().toString());
                    hostInfoModel.setHostNationalID(hostRegNationalID.getText().toString());
                    hostInfoModel.setApproved(isApproved);

                    hostRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue(hostInfoModel)
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d("host_info",e.getMessage());
                                }
                            }).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(HostRegistrationActivity.this, "Succesfully registration done,We will let you know through 24 hours", Toast.LENGTH_SHORT).show();
                                    goToHomeFragment();
                                    uploadNationalIDImageTOStorage();
                                    finish();
                                }
                            });









                }
            }
        });

    }

    private void uploadNationalIDImageTOStorage() {
        if (nationalIdimgUri != null && holdingNationalIdimgUri != null){
            String unique_name = FirebaseAuth.getInstance().getCurrentUser().getUid();
            StorageReference hostRegistrationImageFolder = storageReference.child("hostRegistrationImageFolder/"+unique_name);
            hostRegistrationImageFolder.putFile(nationalIdimgUri)
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d("img_folder",e.getMessage());
                        }
                    }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                            if (task.isSuccessful()){
                                hostRegistrationImageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        Map<String,Object> updateDta = new HashMap<>();
                                        updateDta.put("avatar",uri.toString());
                                        UserUtills.updateHostData(context,updateDta);
                                    }
                                });
                            }
                        }
                    });
        }
    }

    private void goToHomeFragment() {
//        FragmentManager fragmentManager = getSupportFragmentManager();
//        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//
//        HomeFragment fragment = new HomeFragment();
//        fragmentTransaction.add(R.id.nav_host_fragment_content_driver_home, fragment);
//        fragmentTransaction.commit();
        startActivity(new Intent(HostRegistrationActivity.this,MainActivity.class));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_NATINAL_ID_IMG_REQUEST && resultCode == RESULT_OK){
            if (data != null && data.getData() != null){
                nationalIdimgUri = data.getData();
                hostNationalId.setImageURI(nationalIdimgUri);
                clickToUploadNationalId.setVisibility(View.GONE);

            }
        }

        if (requestCode == HOLDING_NATINAL_ID_IMG_REQUEST && resultCode == RESULT_OK){
            if (data != null && data.getData() != null){
                holdingNationalIdimgUri = data.getData();
                hostHoldingNationalId.setImageURI(holdingNationalIdimgUri);
                holdYourNationalIDinYourHands.setVisibility(View.GONE);

            }
        }
    }
}